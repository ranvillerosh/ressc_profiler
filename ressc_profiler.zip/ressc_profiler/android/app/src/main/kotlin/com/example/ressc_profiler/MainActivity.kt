package com.example.ressc_profiler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
