class Training{

}