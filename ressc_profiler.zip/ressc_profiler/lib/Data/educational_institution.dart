class EducationalInstitution {
  //x

}