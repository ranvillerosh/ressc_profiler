class Office {
  String? roomNumber;
  String? buildingNumber;
  String? buildingName;
  String? compound;
  String? streetName;
  String? purok;
  String? barangay;
  String? district;
  String? municipality;
  String? city;
}